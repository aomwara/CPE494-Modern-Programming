package lab1;

interface Shape {

    double getArea();

    double getPerimeter();

}